﻿namespace $rootnamespace$;

public sealed class $safeitemname$
{
}

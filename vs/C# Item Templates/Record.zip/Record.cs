﻿namespace $rootnamespace$;

public sealed record $safeitemname$
{
}
